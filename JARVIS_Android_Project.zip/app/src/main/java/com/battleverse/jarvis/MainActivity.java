package com.battleverse.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_SPEECH = 101;
    private static final int REQ_MIC = 102;
    private TextToSpeech tts;
    private TextView status, reply;
    private LinearLayout root;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 12, 18));
        getWindow().setNavigationBarColor(Color.rgb(8, 12, 18));
        tts = new TextToSpeech(this, this);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(34), dp(22), dp(24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(12, 17, 25));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("JARVIS");
        title.setTextColor(Color.rgb(255, 193, 7));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 38);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL VOICE ASSISTANT");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = matchWrap(); sp.topMargin = dp(4); sp.bottomMargin = dp(28);
        root.addView(subtitle, sp);

        status = new TextView(this);
        status.setText("Ready — tap the button and speak");
        status.setTextColor(Color.rgb(255, 213, 79));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(10), dp(12), dp(10), dp(12));
        root.addView(status, matchWrap());

        reply = new TextView(this);
        reply.setText("Try: “What time is it?”, “Open YouTube”, “Open settings”, or “Search Minecraft shaders”.");
        reply.setTextColor(Color.WHITE);
        reply.setTextSize(17);
        reply.setGravity(Gravity.CENTER);
        reply.setPadding(dp(12), dp(22), dp(12), dp(22));
        LinearLayout.LayoutParams rp = matchWrap(); rp.bottomMargin = dp(18);
        root.addView(reply, rp);

        Button speak = button("🎙  TALK TO JARVIS");
        speak.setOnClickListener(v -> listen());
        root.addView(speak, matchWrap());

        addGap(14);
        addQuickButton("OPEN YOUTUBE", v -> openUrl("https://www.youtube.com"));
        addQuickButton("OPEN CHROME / WEB SEARCH", v -> openUrl("https://www.google.com"));
        addQuickButton("PHONE SETTINGS", v -> openSettings());
        addQuickButton("TIME & DATE", v -> tellTime());
        addQuickButton("WHATSAPP MESSAGE", v -> askWhatsApp());
        addGap(16);
        TextView note = new TextView(this);
        note.setText("Voice recognition uses Android's speech service and may need internet. WhatsApp messages open for you to review and send. “Hey JARVIS” always-listening is not enabled.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.rgb(16, 20, 26));
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255, 193, 7)));
        return b;
    }
    private void addQuickButton(String text, View.OnClickListener listener) {
        Button b = button(text);
        LinearLayout.LayoutParams p = matchWrap(); p.topMargin = dp(7);
        root.addView(b, p);
        b.setOnClickListener(listener);
    }
    private void addGap(int h) {
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private void listen() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            say("Please allow microphone access, then tap the button again.");
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS");
        try {
            status.setText("Listening…");
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            status.setText("Speech recognition unavailable");
            say("Speech recognition is not available on this phone.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String command = results.get(0);
                    reply.setText("You: " + command);
                    handleCommand(command);
                } else {
                    status.setText("Didn't catch that. Try again.");
                }
            } else {
                status.setText("Ready — tap the button and speak");
            }
        }
    }

    private void handleCommand(String raw) {
        String c = raw.toLowerCase(Locale.ROOT).trim();
        if (c.contains("time") || c.contains("date") || c.contains("day")) {
            tellTime();
        } else if (c.contains("open youtube") || c.equals("youtube")) {
            say("Opening YouTube."); openUrl("https://www.youtube.com");
        } else if (c.contains("open chrome") || c.contains("open google") || c.contains("search")) {
            String q = c.replace("open chrome", "").replace("open google", "").replace("search", "").trim();
            if (q.isEmpty()) { say("Opening Google."); openUrl("https://www.google.com"); }
            else { say("Searching the web."); openUrl("https://www.google.com/search?q=" + Uri.encode(q)); }
        } else if (c.contains("settings")) {
            say("Opening phone settings."); openSettings();
        } else if (c.contains("whatsapp")) {
            say("Opening WhatsApp message setup."); askWhatsApp();
        } else if (c.contains("hello") || c.contains("hi jarvis") || c.equals("hello jarvis")) {
            say("Hello! I am JARVIS. How can I help you?");
        } else if (c.contains("who are you")) {
            say("I am JARVIS, your personal voice assistant.");
        } else if (c.contains("help")) {
            say("You can ask me for the time, open YouTube, open settings, search the web, or prepare a WhatsApp message.");
        } else {
            say("I heard: " + raw + ". I can open apps, tell the time, or search the web. Try saying search followed by your question.");
        }
        status.setText("Ready");
    }

    private void tellTime() {
        String now = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT, Locale.getDefault()).format(new Date());
        reply.setText(now);
        status.setText("Time and date");
        say("It is " + DateFormat.getTimeInstance(DateFormat.SHORT, Locale.getDefault()).format(new Date()) +
             ". Today is " + DateFormat.getDateInstance(DateFormat.FULL, Locale.getDefault()).format(new Date()));
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { say("I could not open that link."); }
    }
    private void openSettings() {
        try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
        catch (Exception e) { say("I could not open settings."); }
    }
    private void askWhatsApp() {
        // Safe flow: user reviews the draft and presses Send.
        android.widget.EditText phone = new android.widget.EditText(this);
        phone.setHint("Phone number with country code, e.g. 923001234567");
        android.widget.EditText message = new android.widget.EditText(this);
        message.setHint("Message");
        message.setText("Hello! Sent from my JARVIS assistant.");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), dp(8));
        layout.addView(phone, matchWrap());
        layout.addView(message, matchWrap());
        new android.app.AlertDialog.Builder(this)
            .setTitle("Prepare WhatsApp message")
            .setView(layout)
            .setNegativeButton("Cancel", (d, w) -> {})
            .setPositiveButton("Open WhatsApp", (d, w) -> {
                String number = phone.getText().toString().replaceAll("[^0-9]", "");
                String text = message.getText().toString();
                if (number.isEmpty()) { say("Please enter a phone number with country code."); return; }
                openUrl("https://wa.me/" + number + "?text=" + Uri.encode(text));
            }).show();
    }

    private void say(String text) {
        reply.setText(text);
        if (ttsReady && tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance");
    }
    @Override public void onInit(int statusCode) {
        if (statusCode == TextToSpeech.SUCCESS) {
            int r = tts.setLanguage(Locale.getDefault());
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            status.setText("Microphone allowed — tap TALK TO JARVIS");
        }
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
