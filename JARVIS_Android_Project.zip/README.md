# JARVIS Android Starter

This is a starter Android project for a Samsung Galaxy Note 10+ / Android phone.

## Included
- Dark black-and-yellow interface
- Tap-to-talk speech recognition (uses Android speech service)
- Text-to-speech replies
- Basic commands: time/date, YouTube, web search, phone Settings, hello/help
- WhatsApp message draft that opens WhatsApp for the user to review and send

## Not included yet
- Always-on “Hey JARVIS” wake word
- A general AI model/API connection
- Guaranteed control of every app
- Automatic sending of WhatsApp messages

## Build APK using GitHub Actions (no Termux)
1. Create/sign in to a GitHub account.
2. Create a new repository, e.g. `jarvis-android`.
3. Upload the contents of this ZIP into the repository (the `.github` folder must be included).
4. Open the repository's **Actions** tab.
5. Enable workflows if GitHub asks.
6. Choose **Build JARVIS APK** → **Run workflow**.
7. When complete, open the successful workflow run and download the `JARVIS-debug-apk` artifact.
8. Extract the downloaded artifact ZIP and install `app-debug.apk` on your phone. Android may ask you to allow installs from that source.

## Important
This source has not been compiled or tested on your phone in this environment. GitHub Actions builds the APK. Speech recognition and speech output depend on the phone's installed services and language settings. This app uses tap-to-talk, not always-on listening.
